## Bootstrap

#### 错误记录

- 汉堡按钮无法显示出折叠的导航栏

```html
<button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
.navbar-collapse 而不是 navbar-collapse
```

- `url`无法加载出图片

```css
brackground:url("../images/home/home-gb.jpg")
/*注意不要忘了加..*/
```

- 加上`navbar-fixed-top`之后，浏览器无能scroll了

// 后面的页面代码被写到 <nav>标签里面去了

#### 知识记录

- 什么时候用padding，什么时候用margin

```python
# 考虑以下三个方面
1. 是在border内侧增加空白还是外侧增加空白
2. 空白需不需要背景覆盖
3. 空白需不需要叠加
```

- 导航栏总结

```python
# 导航栏首先被 nav 导航元素包裹，其中定义的类有 navbar navbar-default navbar-fixed-right 等
# 接着是一个导航栏logo，用navbar-header以及navbar-brand来创建
# 最后是导航元素，用 nav navbar-nav navbar-right 等创建
------------------------------------------------------
# 如果要添加响应式导航，需要加入汉堡包导航按钮以及对应的属性
# 小页面对应的汉堡包按钮 toggle是开关控件，开关空间对应的数据是collapse，即折叠
<button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
           </button>
        
   # 与大页面对接的属性     
  <div class="navbar-collapse collapse">
```

