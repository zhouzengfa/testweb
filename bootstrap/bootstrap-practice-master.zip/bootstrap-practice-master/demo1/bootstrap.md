## Bootstrap

#### 错误记录

- 汉堡按钮无法显示出折叠的导航栏

```html
<button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
.navbar-collapse 而不是 navbar-collapse
```

- `url`无法加载出图片

```css
brackground:url("../images/home/home-gb.jpg")
/*注意不要忘了加..*/
```

- 加上`navbar-fixed-top`之后，浏览器无能scroll了

// 后面的页面代码被写到 <nav>标签里面去了

#### 知识记录

- 什么时候用padding，什么时候用margin

```python
# 考虑以下三个方面
1. 是在border内侧增加空白还是外侧增加空白
2. 空白需不需要背景覆盖
3. 空白需不需要叠加
```

